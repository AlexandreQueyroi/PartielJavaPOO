package com.camping.exception;

public class LocationException extends Exception {

    /* TODO QUESTION : Selon vous, A quoi sert ce constructeur ?
       Votre réponse :
     */
    public LocationException(String message) {
        super(message);
    }
}
